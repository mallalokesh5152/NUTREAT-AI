GitHub Pages Hosting Steps:
1. Create a new GitHub repository.
2. Upload index.html to the repository.
3. Go to Settings > Pages.
4. Select Branch: main and Folder: /root.
5. Click Save.
6. After a few minutes, GitHub will give a live website link.

Nutreat Life Embed Code:
After GitHub Pages gives your link, paste it inside this code:

<iframe src="YOUR_GITHUB_PAGES_LINK" style="width:100%;height:760px;border:none;border-radius:20px;"></iframe>

This can be added to the Nutreat Life website as an AI Seasonal Recommendation section.
